# Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.

from functools import partial
from typing import Callable, List, Optional, Union

import torch
from torch._utils import _flatten_dense_tensors, _unflatten_dense_tensors

try:
    from torch.distributed._tensor import DTensor, distribute_tensor

    HAVE_DTENSOR = True
except ImportError:
    HAVE_DTENSOR = False

from megatron.core.pipeline_parallel.utils import (
    get_pp_last_rank,
    is_pp_first_stage,
    is_pp_last_stage,
)
from megatron.core.process_groups_config import ProcessGroupCollection

from .. import parallel_state
from ..num_microbatches_calculator import get_num_microbatches
from ..transformer.moe.moe_utils import (
    expert_load_entropy,
    expert_load_violation_batchwise,
    get_updated_expert_bias,
    recover_qb_beta_from_histogram,
    save_to_aux_losses_tracker,
)
from ..transformer.transformer_config import TransformerConfig
from ..utils import (
    get_attr_wrapped_model,
    get_model_config,
    get_pg_size,
    get_tensor_model_parallel_group_if_none,
)


def _get_main_grad_attr(param: torch.nn.Parameter):
    if hasattr(param, "main_grad"):
        return "main_grad"
    return "grad"


def _unshard_if_dtensor(tensor: Union[torch.Tensor, "DTensor"]) -> torch.Tensor:
    """
    Unshards the input tensor if it is a DTensor and otherwise returns the
    tensor unmodified.

    Args:
        tensor (Union[torch.Tensor, DTensor]): The tensor to potentially unshard.

    Returns:
        An unsharded version of the input tensor if it is a DTensor, or the
        input tensor unmodified if it is not a DTensor.
    """
    if HAVE_DTENSOR and isinstance(tensor, DTensor):
        unsharded_tensor = tensor.full_tensor()
        for k, v in vars(tensor).items():
            setattr(unsharded_tensor, k, v)
        return unsharded_tensor
    return tensor


def _reshard_if_dtensor(
    tensor_to_shard: torch.Tensor, reference_tensor: Union[torch.Tensor, "DTensor"]
) -> Union[torch.Tensor, "DTensor"]:
    """
    Reshards the input tensor to match the sharding configuration of the
    reference tensor if the reference tensor is a DTensor. Otherwise, returns
    the reference tensor unmodified.

    Args:
        tensor_to_shard (torch.Tensor): The tensor to be potentially sharded.
        reference_tensor (Union[torch.Tensor, DTensor]): The reference tensor
            for the sharding configuration.

    Returns:
        Union[torch.Tensor, DTensor]: The sharded tensor matching the reference tensor's
        configuration, or the reference tensor itself if it is not a DTensor.
    """
    if HAVE_DTENSOR and isinstance(reference_tensor, DTensor):
        sharded_tensor = distribute_tensor(
            tensor_to_shard,
            device_mesh=reference_tensor.device_mesh,
            placements=reference_tensor.placements,
        )
        for k, v in vars(reference_tensor).items():
            setattr(sharded_tensor, k, v)
        return sharded_tensor
    return reference_tensor


def _allreduce_conditional_embedding_grads(
    model: List[torch.nn.Module],
    config: TransformerConfig,
    pp_group: Optional[torch.distributed.ProcessGroup] = None,
):
    """
    All-reduce conditional embedding grads.

    Reduce grads across all the pp stages to ensure that parameters of the conditional embedders
    (e.g., timestep embedder, FPS embedder, label embedder) stay in sync.
    This is for the models with replicated embedders on each PP / VPP rank, like diffusion models.
    """
    if pp_group is None:
        pp_group = parallel_state.get_pipeline_model_parallel_group()

    if pp_group.size() > 1 and getattr(config, "has_cond_embedder", False):
        grads_dict = {}
        for model_chunk in model:
            for name, param in get_attr_wrapped_model(model_chunk, 'named_parameters')():
                if param.requires_grad and getattr(param, 'pipeline_parallel', False):
                    grad = param.main_grad
                    if name in grads_dict:
                        # Add all the virtual PP rank's gradients to
                        # the first local virtual PP rank.
                        grads_dict[name][0].add_(grad)
                        # Append to the end for later update after cross-rank reduce.
                        grads_dict[name].append(grad)
                    else:
                        grads_dict[name] = [grad]
        if grads_dict:
            # All-reduce the gradient on the first VPP rank.
            grads = [param_grad[0] for _, param_grad in grads_dict.items()]
            coalesced = _flatten_dense_tensors(grads)
            torch.distributed.all_reduce(coalesced, group=pp_group)
            for buf, synced in zip(grads, _unflatten_dense_tensors(coalesced, grads)):
                buf.copy_(synced)

            # Update the gradients on other VPP ranks.
            for grads in grads_dict.values():
                for grad in grads[1:]:
                    grad.copy_(grads[0])


def _get_shared_word_embedding_weight(
    model_module: torch.nn.Module, config: TransformerConfig
) -> Optional[torch.nn.Parameter]:
    """Return the shared word-embedding weight if it is duplicated across stages.

    Args:
        model_module: The model module from which to extract the
            word-embedding weight.
        config: Transformer config.

    Returns:
        The shared embedding or output weight if available; otherwise ``None``.
    """
    # Only reduce if weights are duplicated across stages.
    if model_module.share_embeddings_and_output_weights or getattr(config, 'mtp_num_layers', 0):
        return model_module.shared_embedding_or_output_weight()
    return None


def _get_position_embedding_weight(model_module: torch.nn.Module) -> torch.nn.Parameter:
    """Return the position-embedding weight tensor from the given model module.

    Args:
        model_module: The model module that owns the
            position-embedding parameter.

    Returns:
        The position-embedding weight tensor.
    """
    return getattr(model_module, 'position_embeddings').weight  # type: ignore[attr-defined]


def _allreduce_word_embedding_grads(
    model: List[torch.nn.Module],
    config: TransformerConfig,
    embd_group: Optional[torch.distributed.ProcessGroup] = None,
    pp_group: Optional[torch.distributed.ProcessGroup] = None,
):
    """All-reduce word-embedding gradients across the first and last PP stages.

    This ensures that the ``word_embeddings`` parameters stay in sync when they
    are shared between the input and output layers.

    Args:
        model: A list containing the pipeline chunks
            that constitute the model on the current rank (including any
            virtual pipeline chunks).
        config: Transformer configuration. Used for edge
            cases like MTP where embeddings might be shared differently.
        embd_group: The process
            group over which to all-reduce the word-embedding gradients. If
            ``None``, it will be looked up based on the current pipeline model
            parallel group.
        pp_group: The pipeline
            parallel process group used to identify first/last stages. If
            ``None``, it will be looked up.
    """
    if embd_group is None:
        embd_group = parallel_state.get_embedding_group(check_initialized=False)
        if get_pg_size(embd_group) > 1:
            assert pp_group is None
            pp_group = parallel_state.get_pipeline_model_parallel_group()

    _allreduce_embedding_grad(
        model,
        embd_group,
        pp_group,
        partial(_get_shared_word_embedding_weight, config=config),
        config=config,
    )


def _allreduce_embedding_grad(
    model: List[torch.nn.Module],
    embd_group: torch.distributed.ProcessGroup,
    pp_group: torch.distributed.ProcessGroup,
    weight_getter: Callable[[torch.nn.Module], Optional[torch.nn.Parameter]],
    skip_if_none: bool = True,
    config: TransformerConfig = None,
):
    """Unified helper to all-reduce embedding parameters across pipeline stages.

    Args:
        model (List[torch.nn.Module]): A list of model chunks (PP/VPP).
        embd_group (torch.distributed.ProcessGroup): The process group over which to reduce.
        pp_group (torch.distributed.ProcessGroup): The pipeline parallel process group for
            first/last stage detection.
        weight_getter (Callable[[torch.nn.Module], Optional[torch.nn.Parameter]]): A function
            that takes the *pre-process* model chunk and returns the parameter to be reduced
            (or ``None`` if not applicable).
        skip_if_none (bool, optional): If True, quietly returns when the parameter or its
            gradient is ``None``. Defaults to True.
    """

    if (
        # embd_group can be None in cases there is no embd_group
        # get_pg_size(embd_group) will return 1 and the all-reduce will be skipped.
        get_pg_size(embd_group) > 1
        and torch.distributed.get_rank() in torch.distributed.get_process_group_ranks(embd_group)
    ):

        if is_pp_first_stage(pp_group):
            model_module = model[0]
        elif is_pp_last_stage(pp_group):
            model_module = model[-1]
        elif getattr(config, 'mtp_num_layers', None) is not None and config.mtp_num_layers > 0:
            # Embedding for MTP layers is in the last virtual pipeline model parallel stage.
            model_module = model[-1]
        else:  # We do not support an interleaved schedule for models with encoders yet.
            model_module = model[0]

        ddp_config = model_module.ddp_config
        model_module = get_attr_wrapped_model(model_module, 'pre_process', return_model_obj=True)

        weight = weight_getter(model_module)
        if weight is None and skip_if_none:
            return

        grad_attr = _get_main_grad_attr(weight)
        orig_grad = getattr(weight, grad_attr)
        if ddp_config.use_megatron_fsdp:
            orig_grad = orig_grad._local_tensor if orig_grad is not None else None
        grad = _unshard_if_dtensor(orig_grad)
        # When the embedding is frozen, the grad is None.
        if grad is None and skip_if_none:
            return
        torch.distributed.all_reduce(grad, group=embd_group)
        setattr(weight, grad_attr, _reshard_if_dtensor(grad, orig_grad))


def _allreduce_position_embedding_grads(
    model: List[torch.nn.Module],
    config: TransformerConfig,
    pos_emb_group: torch.distributed.ProcessGroup,
    pp_group: torch.distributed.ProcessGroup,
):
    """
    All-reduce position_embeddings grad across encoder and decoder stages to ensure that position
    embeddings parameters stay in sync.
    """

    _allreduce_embedding_grad(
        model, pos_emb_group, pp_group, _get_position_embedding_weight, skip_if_none=False
    )


def reset_model_temporary_tensors(config: TransformerConfig, model: List[torch.nn.Module]):
    """
    Reset the temporary tensors of the model.
    """
    for model_chunk in model:
        for module in get_attr_wrapped_model(model_chunk, 'modules')():
            if (
                hasattr(module, 'local_tokens_per_expert')
                and module.local_tokens_per_expert is not None
            ):
                module.local_tokens_per_expert.zero_()
            if (
                config.moe_router_load_balancing_type == "global_aux_loss"
                or "global_aux_loss" in config.moe_router_load_balancing_type
            ) and hasattr(module, 'reset_global_aux_loss_tracker'):
                module.reset_global_aux_loss_tracker()
            if getattr(module, 'qb_beta_accum', None) is not None:
                module.qb_beta_accum.zero_()
                module.qb_beta_count.zero_()
            if getattr(module, 'qb_histogram', None) is not None:
                module.qb_histogram.zero_()
            if getattr(module, 'expert_load_sample_count', None) is not None:
                module.expert_load_sample_count.zero_()


def _log_microbatch_router_metrics(
    model: List[torch.nn.Module],
    config: TransformerConfig,
    dp_group: torch.distributed.ProcessGroup,
):
    """Reduce batched expert counts and log exact TP/CP-aware MBS and sequence metrics."""
    enabled_metrics = set(config.moe_router_violation_metrics)
    if not enabled_metrics:
        return

    # Repeated MTP routers contribute multiple logical depths to one tracker slot. Aggregate
    # metrics remain correct, but per-layer attribution combines those depths.

    collect_mbs = bool(enabled_metrics & {'mbs', 'ep'})
    collect_seq = 'seq' in enabled_metrics
    router_modules = []
    microbatch_counts = []
    mbs_sample_sizes = []
    seq_sample_sizes = []
    samples = []
    for model_chunk in model:
        for module in get_attr_wrapped_model(model_chunk, 'modules')():
            sample_count_tensor = getattr(module, 'expert_load_sample_count', None)
            if sample_count_tensor is None:
                continue
            sample_count = int(sample_count_tensor.item())
            if sample_count == 0:
                continue

            mbs_samples = getattr(module, 'mbs_expert_load_samples', None)
            seq_samples = getattr(module, 'seq_expert_load_samples', None)
            capacity = mbs_samples.shape[0]
            if sample_count > capacity:
                raise RuntimeError(
                    f"Collected {sample_count} router metric samples in a buffer with capacity "
                    f"{capacity}. The number of router forwards exceeded the configured number "
                    "of microbatches."
                )

            module_samples = []
            router_modules.append(module)
            microbatch_counts.append(sample_count)
            if collect_mbs:
                module_mbs_samples = mbs_samples[:sample_count]
                mbs_sample_sizes.append(sample_count)
                module_samples.append(module_mbs_samples)
            else:
                mbs_sample_sizes.append(0)
            if collect_seq:
                assert seq_samples is not None
                module_seq_samples = seq_samples[:sample_count].flatten(0, 1)
                seq_sample_sizes.append(module_seq_samples.shape[0])
                module_samples.append(module_seq_samples)
            else:
                seq_sample_sizes.append(0)
            samples.append(
                torch.cat(module_samples) if len(module_samples) > 1 else module_samples[0]
            )

    if not samples:
        return

    stacked_samples = torch.cat(samples)
    # Pool additive token counts before computing nonlinear violation metrics.
    torch.distributed.all_reduce(
        stacked_samples,
        op=torch.distributed.ReduceOp.SUM,
        group=router_modules[0].tp_cp_group,
    )

    num_layers = config.num_layers
    if config.mtp_num_layers is not None:
        num_layers += config.mtp_num_layers

    def save_metrics(
        prefix: str,
        module: torch.nn.Module,
        module_samples: torch.Tensor,
        samples_per_microbatch: int = 1,
    ):
        tokens_per_expert = module_samples[:, :-1]
        total_num_tokens = module_samples[:, -1:]
        ideal_tokens_per_expert = total_num_tokens * module.topk / tokens_per_expert.shape[-1]
        violation = torch.where(
            ideal_tokens_per_expert > 0,
            (tokens_per_expert - ideal_tokens_per_expert) / ideal_tokens_per_expert,
            torch.zeros_like(tokens_per_expert),
        )

        for name, values in (
            (f"{prefix}_max_violation", violation.max(dim=-1).values),
            (f"{prefix}_min_violation", violation.min(dim=-1).values),
            (f"{prefix}_median_violation", violation.median(dim=-1).values),
            (f"{prefix}_std_violation", violation.std(dim=-1, correction=0)),
            (f"{prefix}_entropy", expert_load_entropy(tokens_per_expert)),
        ):
            save_to_aux_losses_tracker(
                name,
                values.sum() / samples_per_microbatch,
                module.layer_number,
                num_layers,
                avg_group=dp_group,
            )

    offset = 0
    reduced_mbs_samples = []
    for module, microbatch_count, mbs_sample_count, seq_sample_count in zip(
        router_modules, microbatch_counts, mbs_sample_sizes, seq_sample_sizes
    ):
        module_mbs_samples = stacked_samples[offset : offset + mbs_sample_count]
        offset += mbs_sample_count
        module_seq_samples = stacked_samples[offset : offset + seq_sample_count]
        offset += seq_sample_count

        if 'mbs' in enabled_metrics:
            save_metrics("expert", module, module_mbs_samples)
        if 'ep' in enabled_metrics:
            reduced_mbs_samples.append(module_mbs_samples)
        if 'seq' in enabled_metrics:
            assert seq_sample_count % microbatch_count == 0
            save_metrics(
                "seq_expert",
                module,
                module_seq_samples,
                samples_per_microbatch=seq_sample_count // microbatch_count,
            )

    if 'ep' in enabled_metrics:
        ep_samples = torch.cat(reduced_mbs_samples)
        torch.distributed.all_reduce(ep_samples, group=router_modules[0].ep_group)
        offset = 0
        for module, sample_count in zip(router_modules, mbs_sample_sizes):
            save_metrics("ep_expert", module, ep_samples[offset : offset + sample_count])
            offset += sample_count


def _log_global_router_metrics(model: List[torch.nn.Module], config: TransformerConfig):
    """Log global-batch MoE routing metrics for all MoE routers."""
    router_modules = []
    tokens_per_expert_list = []
    for model_chunk in model:
        for module in get_attr_wrapped_model(model_chunk, 'modules')():
            if (
                hasattr(module, 'local_tokens_per_expert')
                and module.local_tokens_per_expert is not None
            ):
                router_modules.append(module)
                tokens_per_expert_list.append(module.local_tokens_per_expert)

    if len(router_modules) == 0:
        return

    stacked = torch.stack(tokens_per_expert_list, dim=0).clone()
    torch.distributed.all_reduce(
        stacked,
        group=parallel_state.get_tensor_and_data_parallel_group(with_context_parallel=True),
    )

    num_layers = config.num_layers
    if config.mtp_num_layers is not None:
        num_layers += config.mtp_num_layers

    # track_moe_metrics applies value times loss_scale=1/num_microbatches, so pre-multiply
    # to cancel it out because this already contains all microbatch routing counts.
    num_microbatches = get_num_microbatches()
    with torch.no_grad():
        for module, global_tokens_per_expert in zip(router_modules, stacked):
            total_num_tokens = int(global_tokens_per_expert.sum().item()) // module.topk
            max_violation, min_violation, median_violation = expert_load_violation_batchwise(
                tokens_per_expert=global_tokens_per_expert,
                num_experts=global_tokens_per_expert.shape[0],
                total_num_tokens=total_num_tokens,
                topk=module.topk,
            )
            ideal_tokens_per_expert = (
                total_num_tokens * module.topk / global_tokens_per_expert.shape[0]
            )
            violation_std = (
                (global_tokens_per_expert - ideal_tokens_per_expert) / ideal_tokens_per_expert
            ).std(correction=0)
            for name, value in (
                ("global_expert_max_violation", max_violation),
                ("global_expert_min_violation", min_violation),
                ("global_expert_median_violation", median_violation),
                ("global_expert_std_violation", violation_std),
                ("global_expert_entropy", expert_load_entropy(global_tokens_per_expert)),
            ):
                save_to_aux_losses_tracker(
                    name,
                    value * num_microbatches,
                    module.layer_number,
                    num_layers,
                    reduce_group_has_dp=True,
                )


def _update_router_expert_bias(model: List[torch.nn.Module], config: TransformerConfig):
    """
    Update the expert bias of the router for a global batch.
    This requires all-reduce of local_tokens_per_expert across TPxCPxDP ranks
    """
    tokens_per_expert_list = []
    expert_bias_list = []
    for model_chunk in model:
        for module in get_attr_wrapped_model(model_chunk, 'modules')():
            # Only update expert_bias if this module is in the training mode. There are special
            # cases where only the student is in training mode but the teacher is in eval mode
            # when using online knoweldge-distillation with Model-Optimizer. In this case, we want
            # to avoid updating teacher's expert_bias.
            if hasattr(module, 'expert_bias') and module.training:
                tokens_per_expert_list.append(module.local_tokens_per_expert)
                expert_bias_list.append(module.expert_bias)
    # For hybrid models with both MoE and Dense layers, this list can be empty.
    if len(expert_bias_list) == 0:
        return
    stacked_tokens_per_expert = torch.stack(tokens_per_expert_list, dim=0)
    stacked_expert_bias = torch.stack(expert_bias_list, dim=0)
    stacked_updated_expert_bias = get_updated_expert_bias(
        stacked_tokens_per_expert, stacked_expert_bias, config.moe_router_bias_update_rate
    )

    for expert_bias, updated_expert_bias in zip(expert_bias_list, stacked_updated_expert_bias):
        expert_bias.copy_(updated_expert_bias)


def _update_router_qb_beta(
    model: List[torch.nn.Module],
    config: TransformerConfig,
    dp_cp_group: Optional[torch.distributed.ProcessGroup] = None,
    tp_dp_cp_group: Optional[torch.distributed.ProcessGroup] = None,
):
    """Update the quantile-balancing per-expert bias once per global batch."""
    if config.moe_router_quantile_balancing_method == 'histogram':
        assert tp_dp_cp_group is not None, (
            "Histogram quantile balancing requires a TP+DP+CP process group."
        )
        qb_beta_list = []
        qb_histogram_list = []
        for model_chunk in model:
            for module in get_attr_wrapped_model(model_chunk, 'modules')():
                if getattr(module, 'qb_histogram', None) is not None and module.training:
                    qb_beta_list.append(module.qb_beta)
                    qb_histogram_list.append(module.qb_histogram)

        if len(qb_beta_list) == 0:
            return

        stacked_beta = torch.stack(qb_beta_list, dim=0)
        stacked_histogram = torch.stack(qb_histogram_list, dim=0)
        torch.distributed.all_reduce(
            stacked_histogram,
            op=torch.distributed.ReduceOp.SUM,
            group=tp_dp_cp_group, # We need all the tokens from the global batch to estimate the quantile
        )

        estimated_beta = recover_qb_beta_from_histogram(
            stacked_histogram, stacked_beta, config.moe_router_topk
        )
        ema = config.moe_router_quantile_balancing_ema
        stacked_new_beta = ema * stacked_beta + (1.0 - ema) * estimated_beta

        stacked_new_beta = stacked_new_beta - stacked_new_beta.mean(dim=-1, keepdim=True) # mean center the new beta value

        has_observations = stacked_histogram.sum(dim=(-1, -2)) > 0
        stacked_new_beta = torch.where(
            has_observations.unsqueeze(-1), stacked_new_beta, stacked_beta
        )
        for qb_beta, new_beta in zip(qb_beta_list, stacked_new_beta):
            qb_beta.copy_(new_beta)
        return

    qb_beta_list = []
    qb_beta_accum_list = []
    qb_beta_count_list = []
    for model_chunk in model:
        for module in get_attr_wrapped_model(model_chunk, 'modules')():
            if getattr(module, 'qb_beta_accum', None) is not None and module.training:
                qb_beta_list.append(module.qb_beta)
                qb_beta_accum_list.append(module.qb_beta_accum)
                qb_beta_count_list.append(module.qb_beta_count)

    if len(qb_beta_list) == 0:
        return

    stacked_beta = torch.stack(qb_beta_list, dim=0)
    stacked_accum = torch.stack(qb_beta_accum_list, dim=0)
    stacked_count = torch.stack(qb_beta_count_list, dim=0)

    # NOTE: average quantile_balancing gathers router scores across TP/CP before accumulating beta,
    # so TP/CP replicas already contribute sequence-wide beta estimates here. Revisit
    # this reduction if the TP/CP gather is removed or narrowed.

    # Use async op to enqueue both collectives so as to reduce CPU overhead of the calls.
    accum_reduce = torch.distributed.all_reduce(
        stacked_accum, op=torch.distributed.ReduceOp.SUM, group=dp_cp_group, async_op=True
    )
    count_reduce = torch.distributed.all_reduce(
        stacked_count, op=torch.distributed.ReduceOp.SUM, group=dp_cp_group, async_op=True
    )

    accum_reduce.wait()
    count_reduce.wait()

    count = stacked_count.clamp(min=1).to(stacked_accum.dtype).unsqueeze(-1)
    stacked_global_avg = torch.where(
        stacked_count.unsqueeze(-1) > 0, stacked_accum / count, stacked_beta
    )

    ema = config.moe_router_quantile_balancing_ema
    stacked_new_beta = ema * stacked_beta + (1.0 - ema) * stacked_global_avg
    stacked_new_beta = stacked_new_beta - stacked_new_beta.mean(dim=-1, keepdim=True)

    for qb_beta, new_beta in zip(qb_beta_list, stacked_new_beta):
        qb_beta.copy_(new_beta)


def _log_router_bias_metrics(model: List[torch.nn.Module], config: TransformerConfig):
    """Log post-update statistics for the enabled MoE router biases."""
    if not config.moe_router_bias_metrics:
        return

    num_layers = config.num_layers
    if config.mtp_num_layers is not None:
        num_layers += config.mtp_num_layers

    # These statistics are recorded once per global batch. Cancel the microbatch scaling
    # applied by track_moe_metrics.
    num_microbatches = get_num_microbatches()
    uses_quantile_balancing = "quantile_balancing" in config.moe_router_load_balancing_type
    with torch.no_grad():
        for model_chunk in model:
            for module in get_attr_wrapped_model(model_chunk, 'modules')():
                if not module.training:
                    continue
                active_biases = []
                if config.moe_router_enable_expert_bias and not uses_quantile_balancing:
                    active_biases.append(('expert_bias', getattr(module, 'expert_bias', None)))
                if uses_quantile_balancing:
                    active_biases.append(('qb_beta', getattr(module, 'qb_beta', None)))
                for metric_prefix, bias in active_biases:
                    if bias is None:
                        continue
                    for statistic, value in (
                        ('mean', bias.mean()),
                        ('std', bias.std(correction=0)),
                        ('min', bias.min()),
                        ('max', bias.max()),
                    ):
                        save_to_aux_losses_tracker(
                            f'{metric_prefix}_{statistic}',
                            value * num_microbatches,
                            module.layer_number,
                            num_layers,
                        )


def _allreduce_non_tensor_model_parallel_grads(
    model: List[torch.nn.Module],
    config: TransformerConfig,
    tp_group: Optional[torch.distributed.ProcessGroup] = None,
):
    """
    All-reduce both layernorm grads (for sequence parallelism) and
    gradients from modules with average_gradients_across_tp_domain=True
    across tensor-model-parallel ranks.
    """
    tp_group = get_tensor_model_parallel_group_if_none(tp_group)
    if tp_group.size() <= 1:
        return

    params_sum = []
    grads_sum = []
    params_avg = []
    grads_avg = []

    for model_chunk in model:
        ddp_config = model_chunk.ddp_config
        for name, param in get_attr_wrapped_model(model_chunk, 'named_parameters')():
            if param.requires_grad:
                # Check if this param needs average reduction (average_gradients_across_tp_domain)
                if getattr(param, "average_gradients_across_tp_domain", False):
                    grad_attr = _get_main_grad_attr(param)
                    grad = getattr(param, grad_attr)
                    if grad is None:
                        continue
                    params_avg.append(param)
                    if ddp_config.use_megatron_fsdp:
                        grads_avg.append(grad._local_tensor.data)
                    else:
                        grad = _unshard_if_dtensor(grad)
                        grads_avg.append(grad.data)
                # Check if this param needs sum reduction (sequence parallel or qk_layernorm)
                elif (config.sequence_parallel and getattr(param, "sequence_parallel", False)) or (
                    config.qk_layernorm and ("q_layernorm" in name or "k_layernorm" in name)
                ):
                    grad_attr = _get_main_grad_attr(param)
                    grad = getattr(param, grad_attr)
                    if grad is None:
                        continue
                    params_sum.append(param)
                    if ddp_config.use_megatron_fsdp:
                        grads_sum.append(grad._local_tensor.data)
                    else:
                        grad = _unshard_if_dtensor(grad)
                        grads_sum.append(grad.data)

    # Loop grads and perform correct all-reduce
    for params, grads, all_reduce_op in zip(
        [params_sum, params_avg],
        [grads_sum, grads_avg],
        [torch.distributed.ReduceOp.SUM, torch.distributed.ReduceOp.AVG],
    ):
        if grads:
            coalesced = _flatten_dense_tensors(grads)
            torch.distributed.all_reduce(coalesced, op=all_reduce_op, group=tp_group)
            for param, buf, synced in zip(
                params, grads, _unflatten_dense_tensors(coalesced, grads)
            ):
                buf.copy_(synced)
                grad_attr = _get_main_grad_attr(param)
                orig_grad = getattr(param, grad_attr)
                if ddp_config.use_megatron_fsdp:
                    setattr(param, grad_attr, orig_grad)
                else:
                    setattr(param, grad_attr, _reshard_if_dtensor(buf, orig_grad))


"""
This is an alias to _allreduce_non_tensor_model_parallel_grads that we must
maintain for legacy tests. We can remove this proxy in mcore 0.14.
"""
_allreduce_layernorm_grads = _allreduce_non_tensor_model_parallel_grads


def finalize_model_grads(
    model: List[torch.nn.Module],
    num_tokens: Optional[torch.Tensor] = None,
    pg_collection: Optional[ProcessGroupCollection] = None,
    force_all_reduce: Optional[bool] = False,
):
    """
    All-reduce all model grads across DP replicas, layernorm grads for sequence parallelism,
    embedding grads across first and last pipeline stages (if not tied),
    scale gradients by `num_tokens`.
    """

    config = get_model_config(model[0])
    uses_histogram_qb = (
        "quantile_balancing" in config.moe_router_load_balancing_type
        and config.moe_router_quantile_balancing_method == 'histogram'
    )
    if pg_collection is not None:
        assert hasattr(pg_collection, 'tp')
        assert hasattr(pg_collection, 'pp')
        assert hasattr(pg_collection, 'embd'), (
            "pg_collection must have a embd. In previous version, it is used default "
            "`parallel_state.default_embedding_ranks` to create the process group."
            " If you are using the default process group, please use"
            " `parallel_state.get_embedding_group()` "
            "If you don't need embd_group, you need to explicitly set it to None."
        )
        assert hasattr(pg_collection, 'pos_embd'), (
            "pg_collection must have a pos_embd. In previous version, it is used default "
            "`parallel_state.default_position_embedding_ranks` to create the process group."
            " If you are using the default process group, please use "
            " `parallel_state.get_position_embedding_group()` "
            "If you don't need pos_embd_group, you need to explicitly set it to None."
        )
        assert hasattr(pg_collection, 'dp_cp')
        tp_group = pg_collection.tp
        pp_group = pg_collection.pp
        embd_group = pg_collection.embd
        pos_emb_group = pg_collection.pos_embd
        dp_cp_group = pg_collection.dp_cp
        dp_group = getattr(pg_collection, 'dp', None)
        if dp_group is None:
            dp_group = parallel_state.get_data_parallel_group(with_context_parallel=False)
        if uses_histogram_qb:
            tp_dp_cp_group = getattr(pg_collection, 'tp_dp_cp', None)
            if tp_dp_cp_group is None:
                tp_dp_cp_group = parallel_state.get_tensor_and_data_parallel_group(
                    with_context_parallel=True
                )
        else:
            tp_dp_cp_group = None
    else:
        tp_group = parallel_state.get_tensor_model_parallel_group()
        pp_group = parallel_state.get_pipeline_model_parallel_group()
        embd_group = parallel_state.get_embedding_group(check_initialized=False)
        pos_emb_group = parallel_state.get_position_embedding_group(check_initialized=False)
        dp_cp_group = parallel_state.get_data_parallel_group(with_context_parallel=True)
        dp_group = parallel_state.get_data_parallel_group(with_context_parallel=False)
        tp_dp_cp_group = (
            parallel_state.get_tensor_and_data_parallel_group(with_context_parallel=True)
            if uses_histogram_qb
            else None
        )

    # All-reduce / reduce-scatter across DP replicas.
    if config.timers is not None:
        config.timers('all-grads-sync', log_level=1).start(barrier=config.barrier_with_L1_time)
    for model_chunk in model:
        model_chunk.finish_grad_sync(force_all_reduce=force_all_reduce)
    if config.timers is not None:
        config.timers('all-grads-sync').stop()

    # All-reduce t_embedder grads (for pp & vpp of DiT).
    if config.timers is not None:
        config.timers('conditional-embedder-grads-all-reduce', log_level=1).start(
            barrier=config.barrier_with_L1_time
        )
    _allreduce_conditional_embedding_grads(model, config, pp_group)
    if config.timers is not None:
        config.timers('conditional-embedder-grads-all-reduce').stop()

    # All-reduce layer-norm grads (for sequence parallelism) and non-tensor parallel modules.
    if config.timers is not None:
        config.timers('non-tensor-parallel-grads-all-reduce', log_level=1).start(
            barrier=config.barrier_with_L1_time
        )
    _allreduce_non_tensor_model_parallel_grads(model, config, tp_group)
    if config.timers is not None:
        config.timers('non-tensor-parallel-grads-all-reduce').stop()

    # All-reduce embedding grads (for pipeline parallelism).
    if config.timers is not None:
        config.timers('embedding-grads-all-reduce', log_level=1).start(
            barrier=config.barrier_with_L1_time
        )
    _allreduce_word_embedding_grads(model, config, embd_group, pp_group)
    _allreduce_position_embedding_grads(model, config, pos_emb_group, pp_group)

    if config.timers is not None:
        config.timers('embedding-grads-all-reduce').stop()

    if config.moe_router_enable_expert_bias:
        _update_router_expert_bias(model, config)

    _log_microbatch_router_metrics(model, config, dp_group)
    _log_global_router_metrics(model, config)

    if "quantile_balancing" in config.moe_router_load_balancing_type:
        _update_router_qb_beta(
            model,
            config,
            dp_cp_group=dp_cp_group,
            tp_dp_cp_group=tp_dp_cp_group,
        )

    _log_router_bias_metrics(model, config)

    reset_model_temporary_tensors(config, model)

    # normalize gradients for per-token loss normalization.
    # if we are using by the number of tokens, then we use that as a divisor. this number
    # will be the total number of non-padded tokens in the global batch.
    if num_tokens is not None:

        # the number of tokens is only present on the last stage, so broadcast it
        # to the other ranks in the pipeline parallel group.
        assert not isinstance(pp_group, list)
        last_rank = get_pp_last_rank(pp_group)
        torch.distributed.broadcast(num_tokens, src=last_rank, group=pp_group)

        # all-reduce across DP ranks.
        torch.distributed.all_reduce(num_tokens, group=dp_cp_group)
        for model_chunk in model:
            if num_tokens > 0:
                scaling = 1.0 / num_tokens
                model_chunk.scale_gradients(scaling)
