# Copyright (c) 2020, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .distributed_data_parallel_config import DistributedDataParallelConfig
from .fully_shard import fully_shard, fully_shard_model, fully_shard_optimizer
from .megatron_fsdp import MegatronFSDP
from .mixed_precision import MixedPrecisionPolicy
from .package_info import (
    __contact_emails__,
    __contact_names__,
    __description__,
    __download_url__,
    __homepage__,
    __keywords__,
    __license__,
    __package_name__,
    __repository_url__,
    __shortversion__,
    __version__,
)
from .utils import FSDPDistributedIndex

__all__ = [
    "DistributedDataParallelConfig",
    "MegatronFSDP",
    "FSDPDistributedIndex",
    "MixedPrecisionPolicy",
    "fully_shard",
    "fully_shard_model",
    "fully_shard_optimizer",
    "__contact_emails__",
    "__contact_names__",
    "__description__",
    "__download_url__",
    "__homepage__",
    "__keywords__",
    "__license__",
    "__package_name__",
    "__repository_url__",
    "__shortversion__",
    "__version__",
]
